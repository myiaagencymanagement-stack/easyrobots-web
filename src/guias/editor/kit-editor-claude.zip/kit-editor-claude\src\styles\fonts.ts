import { loadFont as montserrat } from "@remotion/google-fonts/Montserrat";

export const MONTSERRAT = montserrat("normal", { weights: ["500", "700", "800", "900"], subsets: ["latin", "latin-ext"] }).fontFamily;
