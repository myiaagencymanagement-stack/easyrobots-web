"""Transcribe un video/audio con faster-whisper y guarda las palabras con sus tiempos.

Uso:  python scripts/transcribe.py public/videos/<id>/source.mp4 videos/<id>/words.json
- Modelo "medium" en CPU (bueno en espanol). Si va lento: "small". Si tienes GPU NVIDIA: device="cuda".
- PISTAS: pon en initial_prompt las palabras raras de tu nicho (marcas, nombres) para que las oiga bien.
"""
import json, sys
from faster_whisper import WhisperModel

PISTAS = "Instagram, IA, Claude, reels."

src, out = sys.argv[1], sys.argv[2]
model = WhisperModel("medium", device="cpu", compute_type="int8")
segments, info = model.transcribe(src, language="es", word_timestamps=True, vad_filter=True, initial_prompt=PISTAS)
words, text = [], []
for seg in segments:
    text.append(seg.text.strip())
    for w in seg.words:
        words.append({"w": w.word.strip(), "start": round(w.start, 2), "end": round(w.end, 2)})
json.dump({"text": " ".join(text), "words": words}, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(" ".join(text))
