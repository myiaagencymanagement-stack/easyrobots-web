import React from "react";
import { AbsoluteFill, Easing, interpolate, spring } from "remotion";
import { useSourceTime } from "./time";
import type { HookPart, HookPlan } from "./types";

/**
 * Logica comun del hook de arriba (igual en todos los estilos):
 * entra al empezar, se encoge en `shrinkAt` y se queda arriba, y cambia de
 * texto en cada `swap`. Cada estilo solo pone el aspecto (Tag, Line, Box).
 */
export const HookBase: React.FC<{
  hook: HookPlan;
  Tag?: React.FC<{ text: string; p: number }>;
  Line: React.FC<{ parts: HookPart[]; enter: number; index: number }>;
  /** caja alrededor de todas las lineas (tarjeta, caja blanca...) */
  Box?: React.FC<{ children: React.ReactNode; p: number }>;
  top?: string;
  /** escala grande -> escala encogida */
  scales?: [number, number];
  gap?: number;
  /** degradado oscuro arriba para que se lea sobre fondos claros */
  shade?: boolean;
}> = ({ hook, Tag, Line, Box, top = "9%", scales = [0.9, 0.82], gap = 12, shade = true }) => {
  const { t, fps } = useSourceTime();
  const start = hook.start ?? 0;
  const end = hook.end ?? Infinity;
  if (t < start || t >= end) return null;

  const fr = (s: number) => Math.max(0, Math.round((t - s) * fps));
  const pill = spring({ frame: fr(start), fps, config: { damping: 9, mass: 0.5 } });
  const shrink =
    hook.shrinkAt === undefined
      ? 0
      : interpolate(t, [hook.shrinkAt, hook.shrinkAt + 0.5], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.inOut(Easing.cubic),
        });
  const swap = [...(hook.swaps ?? [])].reverse().find((s) => t >= s.at);
  const lines = swap ? swap.lines : hook.lines;
  const linesStart = swap ? swap.at : start;
  const enterOf = (i: number) => {
    const f = fr(linesStart) - (swap ? 0 : 4) - i * 4;
    return f < 0 ? 0 : spring({ frame: f, fps, config: { damping: 12, mass: 0.45 } });
  };
  const exit = Number.isFinite(end) ? interpolate(t, [end - 0.25, end], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) : 0;

  const body = lines.map((parts, i) => <Line key={`${linesStart}-${i}`} parts={parts} enter={enterOf(i)} index={i} />);

  return (
    <AbsoluteFill style={{ perspective: 900, opacity: 1 - exit }}>
      {shade && (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: "26%",
            background: "linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.25) 60%, rgba(0,0,0,0) 100%)",
            opacity: 1 - shrink * 0.5,
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          top,
          left: 0,
          right: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap,
          transformOrigin: "50% 0%",
          transform: `translateY(${-20 * shrink}px) scale(${scales[0] + (scales[1] - scales[0]) * shrink})`,
        }}
      >
        {Tag && hook.tag && <Tag text={hook.tag} p={pill} />}
        {Box ? <Box p={enterOf(0)}>{body}</Box> : body}
      </div>
    </AbsoluteFill>
  );
};
