import React, { createContext, useContext } from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";

/**
 * Todo el motor trabaja en "tiempo del video de origen". En un reel normal
 * coincide con el tiempo de la composicion; en el muestrario cada demo es un
 * <Sequence> que empieza en otro punto del video, y este desfase lo corrige.
 */
const Offset = createContext(0);

export const SourceOffset: React.FC<{ frames: number; children: React.ReactNode }> = ({ frames, children }) => (
  <Offset.Provider value={frames}>{children}</Offset.Provider>
);

export const useSourceOffset = () => useContext(Offset);

export const useSourceTime = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const frame = f + useContext(Offset);
  return { frame, t: frame / fps, fps };
};
