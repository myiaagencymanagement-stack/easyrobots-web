import type { Theme } from "../engine/theme";
import { limpio } from "./limpio";

/**
 * Estilos disponibles: el plan elige uno con "style": "<id>".
 * Para crear el tuyo: pidele a Claude "crea un estilo nuevo copiando limpio.tsx" y anadelo aqui.
 */
export const STYLES: Record<string, Theme> = { limpio };
