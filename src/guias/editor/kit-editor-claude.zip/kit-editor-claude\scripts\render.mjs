// Uso:
//   node scripts/render.mjs ep1                 -> out/ep1.mp4 (video + audio final normalizado a -13 LUFS)
//   node scripts/render.mjs ep1 --frame=120     -> out/ep1-120.png (captura para revisar)
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(root);
const [id, ...rest] = process.argv.slice(2);
if (!id) throw new Error("Falta el id del video (carpeta en videos/)");
fs.mkdirSync("out", { recursive: true });
const run = (cmd) => execSync(cmd, { stdio: "inherit", shell: true });
const frameArg = rest.find((a) => a.startsWith("--frame="));

const dir = `videos/${id}`;
const plan = JSON.parse(fs.readFileSync(`${dir}/plan.json`, "utf8"));
plan.captions = JSON.parse(fs.readFileSync(`${dir}/captions.json`, "utf8"));
const props = `${dir}/.props.json`;
fs.writeFileSync(props, JSON.stringify({ plan }));

if (frameArg) {
  run(`npx remotion still src/index.ts Reel out/${id}-${frameArg.split("=")[1]}.png ${frameArg} --props=${props} --log=error`);
  process.exit(0);
}

const raw = `out/${id}-raw.mp4`;
run(`npx remotion render src/index.ts Reel ${raw} --crf=16 --props=${props} --log=error`);

// Audio final, normalizado en 2 pasadas:
//  - si el plan lleva musica o sfx: la mezcla que ya hace el render (voz + musica con ducking + sfx)
//  - si no: el export con musica (audioFrom) o el audio del propio video
const mixInRender = Boolean(plan.music || (plan.sfx && plan.sfx.length));
if (mixInRender && plan.audioFrom) console.log("Aviso: hay music/sfx en el plan, se ignora audioFrom");
const audio = mixInRender ? raw : (plan.audioFrom ?? `public/${plan.video}`);
const measure = execSync(`ffmpeg -hide_banner -i "${audio}" -vn -af loudnorm=I=-13:TP=-1:LRA=11:print_format=json -f null - 2>&1`, {
  shell: true,
  encoding: "utf8",
});
const m = JSON.parse(measure.slice(measure.lastIndexOf("{"), measure.lastIndexOf("}") + 1));
const ln = `loudnorm=I=-13:TP=-1:LRA=11:measured_I=${m.input_i}:measured_TP=${m.input_tp}:measured_LRA=${m.input_lra}:measured_thresh=${m.input_thresh}:offset=${m.target_offset}:linear=true`;
run(`ffmpeg -hide_banner -loglevel error -y -i ${raw} -i "${audio}" -map 0:v -map 1:a -c:v copy -af "${ln}" -ar 48000 -c:a aac -b:a 256k -shortest out/${id}.mp4`);
console.log(`Listo: out/${id}.mp4`);
