import { Config } from "@remotion/cli/config";

// Calidad: frames intermedios en JPEG al 100 (por defecto 80) y video final con CRF bajo.
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(100);
Config.setOverwriteOutput(true);
Config.setCodec("h264");
Config.setCrf(16);
