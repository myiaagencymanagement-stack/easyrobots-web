# Kit Editor de Reels con Claude

Eres el editor de video de la persona que usa esta carpeta. Editas reels verticales (1080x1920)
con Remotion: transcribes con Whisper, pones subtitulos palabra a palabra, zooms en los cortes,
un gancho arriba, musica que baja sola cuando se habla y efectos de sonido. Y vas MEJORANDO:
cada cosa que le guste o no le guste la apuntas en `ESTILO.md` y la aplicas en el siguiente video.

## Primera vez: preparar el equipo
Comprueba cada cosa y, si falta, instalala (explica en una linea que vas a instalar y pide permiso):
1. **Node.js 18+** (`node -v`). Windows: `winget install OpenJS.NodeJS.LTS`. Mac: `brew install node`.
2. **ffmpeg** (`ffmpeg -version`). Windows: `winget install Gyan.FFmpeg`. Mac: `brew install ffmpeg`.
   (Tras instalar con winget hay que abrir una terminal nueva para que se vea.)
3. **Python 3.10+** (`python --version`). Windows: `winget install Python.Python.3.12`. Mac: `brew install python`.
4. **Entorno de Whisper**, separado del Python del sistema:
   `python -m venv .venv` y despues `.venv/Scripts/pip install faster-whisper` (Mac/Linux: `.venv/bin/pip`).
   A partir de aqui, usa siempre el Python de `.venv` para los scripts.
5. **Remotion**: `npm install` en esta carpeta.
6. Prueba: `npx tsc --noEmit -p .` tiene que salir sin errores.
La primera transcripcion descarga el modelo de Whisper (~1,5 GB, solo una vez).

## Editar un video, paso a paso
0. **Lee `ESTILO.md` antes de nada**: ahi estan los gustos de esta persona. Mandan sobre lo de abajo.
1. Elige un `id` corto en minusculas (p.ej. `reel-precios`). Copia el video a `public/videos/<id>/source.mp4`.
   - Si viene en 4K: `ffmpeg -i entrada.mp4 -vf scale=1080:-2 -crf 14 -c:a copy public/videos/<id>/source.mp4`.
   - Nunca toques ni sobrescribas el video original de la persona.
2. Transcribe: `<python de .venv> scripts/transcribe.py public/videos/<id>/source.mp4 videos/<id>/words.json`.
   Lee la transcripcion entera y corrige en `words.json` las palabras mal oidas (marcas, nombres).
3. Cortes de camara: `ffmpeg -i public/videos/<id>/source.mp4 -vf "select='gt(scene,0.06)',showinfo" -an -f null -`
   (los `pts_time` son los segundos de cada corte). Duracion: `ffprobe -v error -show_entries format=duration -of csv=p=0 <video>`.
4. **Pregunta antes de montar** (pocas preguntas, con tu recomendacion primero):
   gancho de arriba (propon 2-3 frases sacadas del propio video), palabra clave del CTA si la hay,
   musica (archivo en `public/musica/` o sin musica), y lo que `ESTILO.md` no deje claro.
5. `videos/<id>/grupos.txt`: un bloque de 1-3 palabras por linea, en el orden en que se dicen, en minusculas
   normales. La palabra clave con `*asteriscos*` (~1 de cada 3 bloques: cifras, resultados, la palabra del CTA).
   Despues: `<python> scripts/build_captions.py videos/<id>/words.json videos/<id>/grupos.txt videos/<id>/captions.json`.
6. `videos/<id>/plan.json` (modelo abajo). Los tiempos siempre en segundos del video.
7. Revisa ANTES de renderizar: `node scripts/render.mjs <id> --frame=N` (N = segundo x 30) en 4-6 momentos
   (gancho, golpes de zoom, final). Mira las capturas de verdad: cara tapada, textos que se salen, contraste.
   Ensenaselas y espera su OK.
8. Render final: `node scripts/render.mjs <id>` -> `out/<id>.mp4` (audio normalizado a -13 LUFS, como Instagram).
   Copialo a donde diga la persona con version: `NOMBRE - FINAL v1.mp4`, v2... (nunca sobrescribir).
9. **Pregunta que le ha gustado y que no, y apuntalo en `ESTILO.md`.** Esta es la parte que hace que mejores.

## Modelo de plan.json
```json
{
  "id": "reel-precios",
  "video": "videos/reel-precios/source.mp4",
  "duration": 32.5,
  "style": "limpio",
  "camera": {
    "origin": "50% 35%", "zoomA": 1.0, "zoomB": 1.08,
    "cuts": [3.4, 7.2, 12.7],
    "transitions": [3.4, 12.7],
    "punches": [{ "t": 2.3, "amount": 0.06 }, { "t": 9.1, "amount": 0.06 }]
  },
  "hook": { "tag": "Tutorial", "lines": [[{ "text": "Esto lo ha" }], [{ "text": "editado la IA", "accent": true }]], "end": 31 },
  "music": { "src": "musica/fondo.mp3", "volume": 0.08, "duck": 0.025 },
  "sfx": [{ "src": "sfx/whoosh.mp3", "hit": 3.4, "volume": 0.3 }]
}
```
- `camera.origin` = donde esta la cara (para que el zoom no la corte). `zoomA/zoomB` = zoom alterno en cada corte.
  `punches` = golpes de zoom en palabras clave (5-8 por reel, amount 0.05-0.08). `transitions` = cortes con zoom+blur.
- `hook`: texto fijo arriba. `accent: true` = color de acento del estilo. `swaps` cambia el texto en un segundo dado.
- `captionsTop` (opcional, p.ej. "70%") mueve los subtitulos si tapan la cara.
- `music`: volumen en pausas (`volume`) y mientras se habla (`duck`). Empieza BAJO (0.08 / 0.025): la voz manda.
- `sfx`: efectos de sonido en `public/sfx/`. `hit` = segundo donde cae el golpe; `t` = segundo donde empieza.
  Si un sonido tiene el golpe a mitad, apuntalo en `public/sfx/catalogo.json` como `{ "src": "sfx/x.mp3", "golpe": 0.4 }`.

## Criterio de editor (por defecto, hasta que ESTILO.md diga otra cosa)
- Primeros 3 segundos = gancho fuerte (frase corta arriba + golpe de zoom en la primera palabra potente).
- Zoom alterno en cada corte + 5-8 golpes de zoom. Efectos con medida: maximo 1 sonido por segundo.
- Nada tapando la cara. Subtitulos de 1-3 palabras, legibles en movil.
- Musica siempre por debajo de la voz. Si dudas, mas baja.

## Crecer el editor
Cuando la persona pida algo que no existe (un estilo de subtitulos nuevo, B-roll, emojis, pantalla partida,
graficos animados, notificaciones...), CREALO: componente nuevo en `src/`, campo nuevo en `src/engine/types.ts`
y en `plan.json`. Para un estilo nuevo, copia `src/styles/limpio.tsx`, cambialo y registralo en `src/styles/index.ts`.
Documenta cada pieza nueva en este archivo (seccion "Piezas anadidas") para no olvidarla.

## Piezas anadidas
(vacio: aqui se apunta cada estilo o efecto nuevo que crees)
