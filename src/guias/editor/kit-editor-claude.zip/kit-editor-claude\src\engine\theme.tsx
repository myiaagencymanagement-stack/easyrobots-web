import React, { createContext, useContext } from "react";
import type { CaptionGroup, HookPlan } from "./types";

export type CaptionsProps = { groups: CaptionGroup[]; compact: boolean; /** altura de los subtitulos (p.ej. "80%"); si no, la del estilo */ top?: string; /** color de las palabras clave (si no, el del estilo) */ accent?: string };
export type HookProps = { hook: HookPlan };

/**
 * Un estilo = tokens de color/fuente (los usan B-roll y efectos) + su propio
 * componente de subtitulos y de hook.
 */
export type Theme = {
  id: string;
  name: string;
  /** fuente de UI (paneles, pastillas) */
  font: string;
  /** fuente y peso de textos grandes (texto detras, frase gigante...) */
  displayFont: string;
  displayWeight: number;
  displayItalic?: boolean;
  displayUpper: boolean;
  accent: string;
  accentGradient: string;
  /** color del texto encima de una pastilla de acento */
  accentText: string;
  /** fondo de los paneles de B-roll y su texto */
  glass: string;
  panelText: string;
  panelBorder: string;
  /** rgba para resplandores */
  glow: string;
  /** canto/sombra del texto grande en 3D (o "none") */
  depth: string;
  Captions: React.FC<CaptionsProps>;
  Hook: React.FC<HookProps>;
};

const Ctx = createContext<Theme | null>(null);

export const ThemeProvider: React.FC<{ theme: Theme; children: React.ReactNode }> = ({ theme, children }) => (
  <Ctx.Provider value={theme}>{children}</Ctx.Provider>
);

export const useTheme = (): Theme => {
  const t = useContext(Ctx);
  if (!t) throw new Error("useTheme fuera de ThemeProvider");
  return t;
};

/** Texto relleno con el degradado de acento del estilo. */
export const AccentText: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => {
  const th = useTheme();
  return (
    <span
      style={{
        backgroundImage: th.accentGradient,
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent",
        ...style,
      }}
    >
      {children}
    </span>
  );
};
