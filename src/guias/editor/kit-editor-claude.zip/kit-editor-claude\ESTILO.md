# Mi estilo de edición

> Claude lee esto antes de cada vídeo y lo amplía después de cada entrega.
> Cada línea: lo que te gusta o no, con la fecha. Lo más nuevo manda sobre lo viejo.

## Mi cuenta
- De qué va mi contenido:
- A quién le hablo:
- Colores / tipografía de marca (si tengo):

## Subtítulos
-

## Gancho y textos
-

## Zooms, cortes y efectos
-

## Música y sonidos
-

## Lo que NO quiero
-
