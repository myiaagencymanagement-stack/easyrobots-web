/** Palabra de subtitulo (texto tal cual se escribio en grupos.txt; cada estilo decide mayusculas). */
export type CaptionWord = { text: string; start: number; end: number; key?: boolean };

/** Grupo de 1-3 palabras que se muestra a la vez. */
export type CaptionGroup = { start: number; end: number; words: CaptionWord[] };

export type CameraPlan = {
  /** punto fijo del zoom (CSS transform-origin), normalmente a la altura de la cara */
  origin: string;
  /** zoom base alterno entre tramos: A en tramos pares, B en impares */
  zoomA: number;
  zoomB: number;
  /** segundos donde hay un corte en el video de origen (ffmpeg scdet) */
  cuts: number[];
  /** subconjunto de cuts que llevan transicion (zoom + blur) */
  transitions: number[];
  /** golpes de zoom sobre palabras clave */
  punches: { t: number; amount: number }[];
};

/** Trozo de texto del hook: gold/accent = color de acento del estilo. */
export type HookPart = { text: string; accent?: boolean; /** letra negra con contorno amarillo (estilo dorado) */ dark?: boolean };

export type HookPlan = {
  tag?: string;
  lines: HookPart[][];
  /** segundo en que el hook se encoge y se queda arriba */
  shrinkAt?: number;
  /** cambios de texto (p.ej. "COMENTAME TUS DUDAS!" en la ultima escena) */
  swaps?: { at: number; lines: HookPart[][] }[];
  /** desde cuando se ve (por defecto 0) y hasta cuando (por defecto siempre) */
  start?: number;
  end?: number;
};

export type Plan = {
  id: string;
  /** ruta dentro de public/ */
  video: string;
  duration: number;
  /** id del estilo de subtitulos (src/styles/index.ts), p.ej. "limpio" */
  style: string;
  camera?: CameraPlan;
  hook?: HookPlan;
  captions?: CaptionGroup[];
  /** volumen del video (0 = mudo) */
  volume?: number;
  /** (solo render.mjs) archivo del que sacar el audio final, p.ej. el export con musica.
   *  Se ignora si hay music o sfx (entonces el audio sale de la propia mezcla del render). */
  audioFrom?: string;
  /** musica aparte que baja sola cuando se habla (ducking) */
  music?: MusicPlan;
  /** efectos de sonido puntuales */
  sfx?: SfxCue[];
  /** altura de los subtitulos (p.ej. "70%"); si no, la del estilo */
  captionsTop?: string;
};

export type MusicPlan = {
  /** ruta dentro de public/ (mp3/wav/m4a) */
  src: string;
  /** volumen en las pausas (0-1, por defecto 0.35) */
  volume?: number;
  /** volumen mientras se habla (por defecto 0.12) */
  duck?: number;
  /** segundo del video en que entra (por defecto 0) y en que se funde (opcional) */
  start?: number;
  end?: number;
  /** segundo de la cancion desde el que empezar */
  from?: number;
};

export type SfxCue = {
  /** ruta dentro de public/, p.ej. "sfx/transicion/whoosh.mp3" (catalogo: public/sfx/catalogo.json) */
  src: string;
  /** segundo del video en que EMPIEZA el sonido... */
  t?: number;
  /** ...o segundo en que debe caer su GOLPE (se resta el "golpe" del catalogo). Usar uno de los dos. */
  hit?: number;
  volume?: number;
};
