import React from "react";
import { AbsoluteFill, interpolate, spring } from "remotion";
import { useSourceTime } from "../engine/time";
import { HookBase } from "../engine/HookBase";
import type { CaptionsProps, HookProps, Theme } from "../engine/theme";
import { MONTSERRAT } from "./fonts";

/**
 * ESTILO 4 · LIMPIO (minimalista, aspecto "nativo" de Instagram/CapCut)
 * Caja blanca redondeada con texto negro (como los textos de CapCut del
 * usuario), sin mayusculas forzadas. La clave se marca en amarillo al
 * decirla, como un subrayador. Para videos que piden poco edit.
 */
const MARK = "#FFE14D";

const Captions: React.FC<CaptionsProps> = ({ groups, compact }) => {
  const { t, fps } = useSourceTime();
  const g = groups.find((x) => t >= x.start && t < x.end);
  if (!g) return null;
  const size = compact ? 42 : 54;
  const gf = Math.round((t - g.start) * fps);
  const box = spring({ frame: gf, fps, config: { damping: 11, mass: 0.4 } });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", top: compact ? "88.5%" : "78%", left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: size * 0.22,
            whiteSpace: "nowrap",
            padding: "10px 22px 12px",
            borderRadius: 16,
            background: "#FFFFFF",
            boxShadow: "0 10px 24px rgba(0,0,0,0.28)",
            transform: `scale(${interpolate(box, [0, 1], [0.82, 1])})`,
            opacity: Math.min(1, box * 2),
          }}
        >
          {g.words.map((w, i) => {
            const said = t >= w.start;
            const hit = w.key && said ? spring({ frame: Math.round((t - w.start) * fps), fps, config: { damping: 14, mass: 0.4 } }) : 0;
            return (
              <span
                key={i}
                style={{
                  position: "relative",
                  display: "inline-block",
                  fontFamily: MONTSERRAT,
                  fontWeight: 800,
                  fontSize: size,
                  lineHeight: 1.15,
                  color: "#111",
                  zIndex: 1,
                }}
              >
                {w.key && (
                  <span
                    style={{
                      position: "absolute",
                      left: -6,
                      right: -6,
                      top: "12%",
                      bottom: "8%",
                      borderRadius: 8,
                      background: MARK,
                      transformOrigin: "0% 50%",
                      transform: `scaleX(${hit})`,
                      zIndex: -1,
                    }}
                  />
                )}
                {w.text}
              </span>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Hook: React.FC<HookProps> = ({ hook }) => (
  <HookBase
    hook={hook}
    shade={false}
    gap={10}
    Tag={({ text, p }) => (
      <div
        style={{
          padding: "6px 22px",
          borderRadius: 999,
          background: "#111",
          color: "#fff",
          fontFamily: MONTSERRAT,
          fontWeight: 800,
          fontSize: 28,
          transform: `scale(${p})`,
        }}
      >
        {text}
      </div>
    )}
    Box={({ children, p }) => (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 2,
          padding: "18px 32px 20px",
          borderRadius: 22,
          background: "rgba(255,255,255,0.96)",
          boxShadow: "0 12px 28px rgba(0,0,0,0.25)",
          transform: `scale(${interpolate(p, [0, 1], [0.8, 1])})`,
          opacity: Math.min(1, p * 2),
        }}
      >
        {children}
      </div>
    )}
    Line={({ parts }) => (
      <div style={{ display: "flex", gap: 12 }}>
        {parts.map((pt, i) => (
          <span
            key={i}
            style={{
              fontFamily: MONTSERRAT,
              fontWeight: 700,
              fontSize: 52,
              lineHeight: 1.18,
              whiteSpace: "nowrap",
              color: "#111",
              background: pt.accent ? MARK : "transparent",
              borderRadius: 8,
              padding: pt.accent ? "0 8px" : 0,
            }}
          >
            {pt.text}
          </span>
        ))}
      </div>
    )}
  />
);

export const limpio: Theme = {
  id: "limpio",
  name: "Limpio",
  font: MONTSERRAT,
  displayFont: MONTSERRAT,
  displayWeight: 900,
  displayUpper: true,
  accent: MARK,
  accentGradient: "linear-gradient(180deg, #FFFFFF 0%, #F4F4F4 100%)",
  accentText: "#111",
  glass: "rgba(255,255,255,0.97)",
  panelText: "#111111",
  panelBorder: "rgba(0,0,0,0.08)",
  glow: "rgba(255,225,77,0.5)",
  depth: "rgba(0,0,0,0.28)",
  Captions,
  Hook,
};
