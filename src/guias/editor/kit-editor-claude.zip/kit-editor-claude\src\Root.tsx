import React from "react";
import { Composition } from "remotion";
import { ReelEngine } from "./engine/ReelEngine";
import type { Plan } from "./engine/types";

const FPS = 30;

const ReelComp: React.FC<{ plan: Plan }> = ({ plan }) => <ReelEngine plan={plan} />;

/** Reel: el plan llega por --props (scripts/render.mjs <id>). */
export const RemotionRoot: React.FC = () => (
  <Composition
    id="Reel"
    component={ReelComp}
    fps={FPS}
    width={1080}
    height={1920}
    durationInFrames={1}
    defaultProps={{ plan: { id: "vacio", video: "", duration: 3, style: "limpio" } as Plan }}
    calculateMetadata={({ props }) => ({ durationInFrames: Math.max(1, Math.round(props.plan.duration * FPS)) })}
  />
);
