import React from "react";
import { AbsoluteFill, Easing, interpolate } from "remotion";
import type { CameraPlan } from "./types";

const TRANSITION_SECONDS = 0.3;
const PUNCH_IN = 0.12;
const PUNCH_OUT = 0.9;

/**
 * "Camara virtual" sobre un plano fijo:
 *   - zoom base alterno en cada corte (A/B), que disimula los jump cuts
 *   - deriva lenta de +4% dentro de cada tramo
 *   - golpes de zoom sobre palabras clave
 *   - en los cortes marcados como transicion, entrada con zoom + blur
 * `extra` lo ponen los efectos de camara (temblor, barrido, giro...).
 */
export const Camera: React.FC<{
  plan?: CameraPlan;
  t: number;
  extra?: { transform: string; filter: string };
  children: React.ReactNode;
}> = ({ plan, t, extra, children }) => {
  let scale = 1;
  let blur = 0;
  if (plan) {
    const segIndex = plan.cuts.filter((c) => c <= t).length;
    const segStart = segIndex === 0 ? 0 : plan.cuts[segIndex - 1];
    const segEnd = plan.cuts[segIndex] ?? segStart + 10;
    const base = segIndex % 2 === 0 ? plan.zoomA : plan.zoomB;
    const drift = interpolate(t, [segStart, segEnd], [0, 0.04], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
    let punch = 0;
    for (const p of plan.punches) {
      const d = t - p.t;
      if (d < 0 || d > PUNCH_IN + PUNCH_OUT) continue;
      punch +=
        d < PUNCH_IN
          ? p.amount * Easing.out(Easing.cubic)(d / PUNCH_IN)
          : p.amount * (1 - Easing.inOut(Easing.cubic)((d - PUNCH_IN) / PUNCH_OUT));
    }
    let transZoom = 0;
    const tr = plan.transitions.find((c) => t >= c && t < c + TRANSITION_SECONDS);
    if (tr !== undefined) {
      const k = 1 - Easing.out(Easing.cubic)((t - tr) / TRANSITION_SECONDS);
      transZoom = 0.35 * k;
      blur = 14 * k;
    }
    scale = base + drift + punch + transZoom;
  }
  const filters = [blur > 0.2 ? `blur(${blur}px)` : "", extra?.filter ?? ""].filter(Boolean).join(" ");

  return (
    <AbsoluteFill
      style={{
        transform: `${extra?.transform ?? ""} scale(${scale})`,
        transformOrigin: plan?.origin ?? "50% 35%",
        filter: filters || undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
