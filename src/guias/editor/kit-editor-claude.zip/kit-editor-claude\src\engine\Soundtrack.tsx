import React, { useMemo } from "react";
import { Audio, Sequence, interpolate, staticFile } from "remotion";
import { useSourceOffset } from "./time";
import type { CaptionGroup, MusicPlan, SfxCue } from "./types";
import catalogo from "../../public/sfx/catalogo.json";

const GOLPE: Record<string, number> = Object.fromEntries((catalogo as { src: string; golpe: number }[]).map((c) => [c.src, c.golpe]));
const startOf = (s: SfxCue) => (s.hit !== undefined ? s.hit - (GOLPE[s.src] ?? 0) : (s.t ?? 0));

/**
 * Musica con "ducking": baja sola mientras se habla (segun los tiempos de las
 * palabras) y sube en las pausas, con rampas suaves. Y efectos de sonido
 * puntuales (plan.sfx). Todo en tiempo del video de origen.
 */
const RAMP = 0.3; // segundos de subida/bajada
const PAD_BEFORE = 0.12;
const PAD_AFTER = 0.2;

export const Soundtrack: React.FC<{ music?: MusicPlan; sfx?: SfxCue[]; captions?: CaptionGroup[]; fps: number }> = ({
  music,
  sfx,
  captions,
  fps,
}) => {
  const offset = useSourceOffset();

  // tramos con voz, fusionando huecos cortos para que no "bombee" entre palabras
  const speech = useMemo(() => {
    const iv = (captions ?? [])
      .flatMap((g) => g.words.map((w) => [w.start - PAD_BEFORE, w.end + PAD_AFTER] as [number, number]))
      .sort((a, b) => a[0] - b[0]);
    const out: [number, number][] = [];
    for (const [a, b] of iv) {
      const last = out[out.length - 1];
      if (last && a - last[1] < 0.45) last[1] = Math.max(last[1], b);
      else out.push([a, b]);
    }
    return out;
  }, [captions]);

  const musicVolume = (f: number) => {
    if (!music) return 0;
    const t = (f + offset) / fps;
    const full = music.volume ?? 0.35;
    const duck = music.duck ?? 0.12;
    let d = Infinity;
    for (const [a, b] of speech) {
      if (t >= a && t <= b) {
        d = 0;
        break;
      }
      d = Math.min(d, t < a ? a - t : t - b);
    }
    const level = duck + (full - duck) * Math.min(1, d / RAMP);
    // fundido de entrada y salida de la musica
    const start = music.start ?? 0;
    const fadeIn = interpolate(t, [start, start + 0.6], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
    const fadeOut = music.end ? interpolate(t, [music.end - 1.2, music.end], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) : 1;
    return level * fadeIn * fadeOut;
  };

  return (
    <>
      {music && (
        <Sequence from={Math.round((music.start ?? 0) * fps) - offset} layout="none">
          <Audio
            src={staticFile(music.src)}
            startFrom={Math.round((music.from ?? 0) * fps)}
            loop
            volume={(f) => musicVolume(f + Math.round((music.start ?? 0) * fps) - offset)}
          />
        </Sequence>
      )}
      {(sfx ?? []).map((s, i) => (
        <Sequence key={i} from={Math.round(startOf(s) * fps) - offset} layout="none">
          <Audio src={staticFile(s.src)} volume={s.volume ?? 0.35} />
        </Sequence>
      ))}
    </>
  );
};
