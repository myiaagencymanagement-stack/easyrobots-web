import React from "react";
import { AbsoluteFill, OffthreadVideo, staticFile } from "remotion";
import { Camera } from "./Camera";
import { ThemeProvider } from "./theme";
import { useSourceTime } from "./time";
import { Soundtrack } from "./Soundtrack";
import type { Plan } from "./types";
import { STYLES } from "../styles";

/**
 * Motor de reels: monta un video a partir de su plan (videos/<id>/plan.json).
 * Capas, de abajo a arriba: camara [video] -> hook -> subtitulos; y el audio (musica + sfx).
 * Para anadir cosas nuevas (B-roll, efectos, estilos) pideselo a Claude: ver CLAUDE.md.
 */
export const ReelEngine: React.FC<{ plan: Plan }> = ({ plan }) => {
  const { t, fps } = useSourceTime();
  const theme = STYLES[plan.style] ?? STYLES.limpio;
  return (
    <ThemeProvider theme={theme}>
      <AbsoluteFill style={{ backgroundColor: "black" }}>
        <Camera plan={plan.camera} t={t} extra={{ transform: "", filter: "" }}>
          {plan.video ? (
            <OffthreadVideo src={staticFile(plan.video)} volume={plan.volume ?? 1} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          ) : null}
        </Camera>
        {plan.hook && <theme.Hook hook={plan.hook} />}
        {plan.captions && <theme.Captions groups={plan.captions} compact={false} top={plan.captionsTop} />}
        <Soundtrack music={plan.music} sfx={plan.sfx ?? []} captions={plan.captions} fps={fps} />
      </AbsoluteFill>
    </ThemeProvider>
  );
};
