"""Agrupa las palabras de Whisper en bloques cortos y marca las palabras clave.

Uso:
    python build_captions.py words.json grupos.txt template/src/captions.json

- words.json: salida de transcribe_fw.py (palabras con timestamps).
- grupos.txt: un bloque por linea (1-3 palabras), en el orden en que se habla.
  La palabra con *asterisco* es la clave (dorado + 30% mas grande).
  Se puede corregir el texto aqui (tildes, palabras mal oidas): el script solo
  exige que cada palabra coincida con la de Whisper ignorando tildes,
  mayusculas y puntuacion; si Whisper oyo otra palabra, corregir words.json.
Los tiempos salen siempre del audio real.
"""
import json, re, sys, unicodedata


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return re.sub(r"[^a-z0-9]", "", "".join(c for c in s if unicodedata.category(c) != "Mn"))


words = json.load(open(sys.argv[1], encoding="utf-8"))["words"]
lines = [l for l in open(sys.argv[2], encoding="utf-8").read().splitlines() if l.strip()]

out, i = [], 0
for line in lines:
    g = []
    for tok in line.split():
        kw = tok.startswith("*")
        text = tok.strip("*")
        w = words[i]
        if norm(w["w"]) != norm(text):
            sys.exit(f"Desajuste en palabra {i}: whisper={w['w']!r} grupos={text!r}")
        g.append({"text": text, "start": w["start"], "end": w["end"], "key": kw})
        i += 1
    out.append({"start": g[0]["start"], "end": g[-1]["end"], "words": g})
assert i == len(words), f"Sobran palabras de whisper: {[w['w'] for w in words[i:]]}"

# cada bloque se queda en pantalla hasta que empieza el siguiente,
# salvo en pausas largas (>0.6s), donde desaparece 0.3s despues de la ultima palabra
for a, b in zip(out, out[1:]):
    a["end"] = b["start"] if b["start"] - a["end"] < 0.6 else round(a["end"] + 0.3, 2)
out[-1]["end"] = round(out[-1]["end"] + 0.6, 2)

json.dump(out, open(sys.argv[3], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"{len(out)} bloques, {sum(w['key'] for g in out for w in g['words'])} palabras clave")
