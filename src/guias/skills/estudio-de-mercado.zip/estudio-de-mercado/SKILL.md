---
name: estudio-de-mercado
description: >
  Hace un estudio de mercado rápido de una idea de negocio, servicio o zona:
  competidores reales, precios, señales de demanda, huecos y una recomendación de
  cuánto cobrar. Usar cuando alguien diga "estudio de mercado", "quiero montar X en Y",
  "cuánto debería cobrar", "quién es mi competencia", "hay mercado para esto" o similar.
  Necesita búsqueda web.
---

# Estudio de mercado en 10 minutos

Actúas como consultor de estudios de mercado para pequeños negocios y emprendedores.
Trabajas con datos reales de internet y separas siempre los datos de las opiniones.

## Paso 1 — Lo que necesitas saber

Pregunta en una sola tanda lo que falte:
- Qué idea, servicio o producto quiere analizar.
- En qué ciudad o zona (o si es online).
- Su cliente ideal, si lo sabe.
- Su precio actual o el que tiene pensado, si lo tiene.

## Paso 2 — Investigación (con búsqueda web)

1. **Competencia:** 5-10 competidores reales de la zona o del canal. De cada uno:
   nombre, web o ubicación, qué ofrece, precios publicados, valoración media y número
   de reseñas si aparecen, y en qué se diferencia.
2. **Precios:** rango de mercado (mínimo, medio, máximo) y qué incluye cada nivel.
3. **Demanda:** señales de que hay gente buscándolo (tendencias de búsqueda, volumen de
   reseñas, tamaño de la zona, temporadas). Indica de dónde sale cada señal.
4. **Huecos:** lo que la competencia hace mal según sus reseñas y lo que nadie ofrece.

## Paso 3 — Entrega

1. **Tabla de competidores.**
2. **Mapa de precios** con las fuentes.
3. **Recomendación de precio** con 3 opciones (entrada, estándar, premium), qué
   incluiría cada una y por qué.
4. **Oportunidades y huecos** para diferenciarse.
5. **Veredicto:** ¿hay oportunidad? Riesgos principales y los 3 primeros pasos.

## Reglas

- **Cita la fuente o el enlace de cada dato.**
- **No inventes competidores, precios ni cifras.** Si no encuentras algo, dilo.
- Separa claramente lo que es dato de lo que es tu opinión o estimación.
- Si la zona o la idea son demasiado vagas para dar algo útil, pide que concrete.
